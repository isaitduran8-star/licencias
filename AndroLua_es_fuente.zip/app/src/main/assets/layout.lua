layout={
  main={
    LinearLayout,
    layout_width="fill",
    layout_height="fill",
    orientation="vertical";
    {
      LuaEditor,
      id="editor",
      text= "",
      layout_width="fill",
      layout_height="fill",
      layout_weight=1 ,
      --gravity="top"
    },
    {
      HorizontalScrollView;
      horizontalScrollBarEnabled=false,
      {
        LinearLayout;
        id="ps_bar";
        layout_width="fill";
      };
      layout_width="fill";
    };
  },

  build={
    ScrollView ,
    layout_width="fill",
    {
      LinearLayout,
      orientation=1,
      layout_width="fill",
      paddingLeft=20,
      {
        TextView,
        text="Ruta del script"
      },
      {
        EditText,
        id="luaPath",
        layout_width="fill",
        singleLine=true,
      },
      {
        TextView,
        text="Nombre del paquete"
      },
      {
        EditText,
        id="packageName",
        layout_width="fill",
        singleLine=true,
      },
      {
        TextView,
        text="Nombre de la aplicación"
      },
      {
        EditText,
        id="appName",
        layout_width="fill",
        singleLine=true,
      },
      {
        TextView,
        text="Versión de la aplicación"
      },
      {
        EditText,
        id="appVer",
        layout_width="fill",
        singleLine=true,
      },
      {
        TextView,
        text="Ruta del APK"
      },
      {
        EditText,
        id="apkPath",
        layout_width="fill",
        singleLine=true,
      },
      {
        TextView,
        text="Compilar usando firma de depuración",
        id="status"
      },
    }
  },

  project={
    ScrollView ,
    layout_width="fill",
    {
      LinearLayout,
      orientation=1,
      layout_width="fill",
      padding="10dp",
      {
        TextView,
        text="Nombre de la aplicación"
      },
      {
        EditText,
        id="project_appName",
        text="demo",
        layout_width="fill",
        singleLine=true,
      },
      {
        TextView,
        text="Nombre del paquete"
      },
      {
        EditText,
        id="project_packageName",
        text="com.androlua.demo",
        layout_width="fill",
        singleLine=true,
      },
    }
  },
  open2={
    LinearLayout;
    orientation="vertical";
    {
      EditText;
      layout_width="fill";
      id="open_edit";
    };
    {
      ListView;
      layout_width="fill";
      id="listview2";
    };
  };


}
